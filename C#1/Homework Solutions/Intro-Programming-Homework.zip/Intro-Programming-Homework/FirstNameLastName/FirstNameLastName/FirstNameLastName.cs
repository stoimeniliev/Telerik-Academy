﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstNameLastName
{
    class FirstNameLastName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Stoimen\nIliev");
            
        }
    }
}
