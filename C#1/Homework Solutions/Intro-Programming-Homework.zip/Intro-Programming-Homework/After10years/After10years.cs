﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace After10years
{
    class After10years
    {
        static void Main(string[] args)
        {
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Your age now is: " + age + "\nYour age after 10 years will be: " + ( age + 10));
        }
    }
}
