﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloatOrDouble
{
    class FloatOrDouble
    {
        static void Main(string[] args)
        {
            double value1 = 34.567839023;
            float value2 = 12.345f;
            double value3 = 8923.1234857;
            float value4 = 3456.091f;
            Console.WriteLine(value1 + " " + value2 + " " + value3 + " " + value4);
        } 
    }
}
