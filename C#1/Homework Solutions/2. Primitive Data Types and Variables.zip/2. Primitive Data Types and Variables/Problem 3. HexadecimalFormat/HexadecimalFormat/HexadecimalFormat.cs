﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HexadecimalFormat
{
    class HexadecimalFormat
    {
        static void Main(string[] args)
        {
            int value1 = 0xFE;
            Console.WriteLine(value1);
        }
    }
}
